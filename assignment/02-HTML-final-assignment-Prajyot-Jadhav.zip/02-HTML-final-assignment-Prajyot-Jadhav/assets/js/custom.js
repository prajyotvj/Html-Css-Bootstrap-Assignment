jQuery(document).ready(function($) {

//wow init script for animate css
new WOW().init();

});
  
	 

